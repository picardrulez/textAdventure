#include <cstdlib>
#include <iostream>
#include <string>
using namespace std;

extern string menuBar;
extern string difficultySetting;
extern int xp;
extern int madechoice;
extern int playerMana;
void clearScreen();
int mainMenu();
int settings();
int credits();
int difficulty();
int itemMenu();
int equipMenu();
int equipmentMenu();
int controls();
int dropItemMenu();
int statusMenu();
void gameMenu();
int displayEquipped();
void displayInventory();
int inventoryMenu();
extern int moneybag;
extern int playersAC;
extern int playersSpeed;
extern int playersAttack;
extern int playerDrunk;
extern int playerHealth;
