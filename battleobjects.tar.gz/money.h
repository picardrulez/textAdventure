#include <cstdlib>
#include <ctime>
using namespace std;

int initialFunds(int classmodifier);
