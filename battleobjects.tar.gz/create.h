using namespace std;

extern int playerLocation;
void createCharacter();
void initialItems();
extern int playersHelmAC;
extern int playersGauntletAC;
extern int playersPlateAC;
extern int playersBootAC;
extern int playersAC;
extern int playersSpeed;
extern int playersAttack;
extern int playerDrunk;
extern int playerHealth;
