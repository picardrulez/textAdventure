#include <string>

using namespace std;
extern int enemy;
string * enemyImage;
string * enemyImageHit;
void enemyWizard();
void displayEnemy(string enemyType);
void displayEnemyShift(string enemyType);
void displayEnemyHit(string enemyType);
