#include <ctime>
#include <unistd.h>
#include <cstdlib>
#include <iostream>
#include "menus.h"
#include "enemies.h"


class Enemy
{
    public:
        string m_enemyName;
        int m_enemyInfo[3];
        //int m_imageLength;
        int m_enemyInvSz;
        int m_enemyInv[$m_enemyInvSz];
        string * enemyImage;
        string * enemyImageHit;
        Enemy(string name, int info0, int info1, int info2, int invsz, string enemyImg, string enemyImgHit);
        void DisplayEnemy();
};

Enemy::Enemy(string name, int info0, int info1, int info2, int invsz, string enemyImg, string enemyImgHit)
{
    m_enemyName = name;
    m_enemyInfo[3] = {info0, info1, info2};
    m_imageLength = length;
    m_enemyInvSz = invsz;
    enemyImage = enemyImg;
    enemyImageHit = enemyImgHit;
}

Enemy::DisplayEnemy()
{
    for (int i = 0; i < sizeof(enemyImage) i++)
    {
        cout << enemyImage[i];
    }
}
//int enemy = 0;
//int enemyInfo[3] = {0,0,0};
//Wizard Stats
//int enemyWizardInfo[3] = {200,20,1};


string enemyWizardImage[12]={
"                       .        \n",
"                       x.       \n",
"                      '',       \n",
"                ..   :  .:.     \n",
"                .' 'Ox;,cO0.    \n",
"                .kOKo:kxxkoXOc  \n",
"                 ,k0.xxkO0.Kk   \n",
"                 ...,0xxOK .,   \n",
"                 .  x0kxkX.     \n",
"                 .  0OkxkX      \n",
"                 .  KkxkOK      \n",
"                  ',. .,c.  '\n\n\n"
};

string enemyWizardImageHit[12]={
"                    .        \n",
"                    x.       \n",
"                   '',       \n",
"             ..   :  .:.     \n",
"             .' 'Ox;,cO0.    \n",
"             .kOKo:kxxkoXOc  \n",
"              ,k0.xxkO0.Kk   \n",
"              ...,0xxOK .,   \n",
"              .  x0kxkX.     \n",
"              .  0OkxkX      \n",
"              .  KkxkOK      \n",
 "              ',. .,c.  '\n\n\n"
};


string enemyOrcImage[]={
"                \n";
"                        coxxdoc:, \n",
"                      ;xdxxxxxdllcc; \n",
"                      oxdxkkxdolcllol, \n",
"                   ,cdkddddxxdxxddooc:,\n",
"                  lkooodxcdoxdxxkxxocc: \n",
"                 ;l,,;lod;clcc:llooc:c:: \n",
"                ,c;.   ...............ccclc:, \n",
"                  ;';. .,lll;,,;:l:'.,:; \n",
"                  cc,;;..:cc;,::co,''oc. \n",
"                  ,dcdll:;:cclc:;l:;;cc,\n",
"                 locdodxkkOOOxo:cllddccc; \n",
"                ,xllllodoodxkkkkkkkxdlcoxkl' \n",
"                ,l;:::cloldxxddddollcccoOOOk; \n",
"               '',,..';clcldolc;'...'';000OOxc \n",
"           ,:colco.  .'.,,,,'.     ..:dk00K0koo::coc \n",
"         :odddol:..           ..';cdoloxkkkxxoc::lodx; \n",
"        :dooddoc:;;'.      ..,;:ldxxo:oxdddol:::loxkkxc \n",
"        :lollc:::c:::;,;llllooccoxkxoclcccc::::clodOOkd; \n",
"          .',,;codddddollolcll:cddddddxdddollcldddxxdl:      \n",
"              ..,cooddddxxo;:;oxOOO000000Okxo:,,'          \n",
"                        ''.. .';:::::::;,  \n"
};

string enemyOrcImageHit[]={
"                     \n",
"                             coxxdoc:, \n",
"                           ;xdxxxxxdllcc; \n",
"                           oxdxkkxdolcllol, \n",
"                        ,cdkddddxxdxxddooc:,\n",
"                       lkooodxcdoxdxxkxxocc: \n",
"                      ;l,,;lod;clcc:llooc:c:: \n",
"                     ,c;.   ...............ccclc:, \n",
"                       ;';. .,lll;,,;:l:'.,:; \n",
"                       cc,;;..:cc;,::co,''oc. \n",
"                       ,dcdll:;:cclc:;l:;;cc,\n",
"                      locdodxkkOOOxo:cllddccc; \n",
"                     ,xllllodoodxkkkkkkkxdlcoxkl' \n",
"                     ,l;:::cloldxxddddollcccoOOOk; \n",
"                    '',,..';clcldolc;'...'';000OOxc \n",
"                ,:colco.  .'.,,,,'.     ..:dk00K0koo::coc \n",
"              :odddol:..           ..';cdoloxkkkxxoc::lodx; \n",
"             :dooddoc:;;'.      ..,;:ldxxo:oxdddol:::loxkkxc \n",
"             :lollc:::c:::;,;llllooccoxkxoclcccc::::clodOOkd; \n",
"               .',,;codddddollolcll:cddddddxdddollcldddxxdl:      \n",
"                   ..,cooddddxxo;:;oxOOO000000Okxo:,,'          \n",
"                             ''.. .';:::::::;,  \n"
};


//displays picture of enemy
void displayEnemy(string enemyType)
{
    if (enemyType == "wizard")
    {
        cout << enemyWizardImage0;
        cout << enemyWizardImage1;
        cout << enemyWizardImage2;
        cout << enemyWizardImage3;
        cout << enemyWizardImage4;
        cout << enemyWizardImage5;
        cout << enemyWizardImage6;
        cout << enemyWizardImage7;
        cout << enemyWizardImage8;
        cout << enemyWizardImage9;
        cout << enemyWizardImage10;
        cout << enemyWizardImage11;
    }
    else if (enemyType == "orc")
    {
        cout << enemyOrcImage0;
        cout << enemyOrcImage1;
        cout << enemyOrcImage2;
        cout << enemyOrcImage3;
        cout << enemyOrcImage4;
        cout << enemyOrcImage5;
        cout << enemyOrcImage6;
        cout << enemyOrcImage7;
        cout << enemyOrcImage8;
        cout << enemyOrcImage9;
        cout << enemyOrcImage10;
        cout << enemyOrcImage11;
        cout << enemyOrcImage12;
        cout << enemyOrcImage13;
        cout << enemyOrcImage14;
        cout << enemyOrcImage15;
        cout << enemyOrcImage16;
        cout << enemyOrcImage17;
        cout << enemyOrcImage18;
        cout << enemyOrcImage19;
        cout << enemyOrcImage20;
        cout << enemyOrcImage21;
    }
 }
    
//displays shifted picture of enemy
void displayEnemyShift(string enemyType)
{
    if (enemyType == "wizard")
    {
        cout << enemyWizardImageHit0;
        cout << enemyWizardImageHit1;
        cout << enemyWizardImageHit2;
        cout << enemyWizardImageHit3;
        cout << enemyWizardImageHit4;
        cout << enemyWizardImageHit5;
        cout << enemyWizardImageHit6;
        cout << enemyWizardImageHit7;
        cout << enemyWizardImageHit8;
        cout << enemyWizardImageHit9;
        cout << enemyWizardImageHit10;
        cout << enemyWizardImageHit11;
    }
    else if (enemyType == "orc")
    {
        cout << enemyOrcImageHit0;
        cout << enemyOrcImageHit1;
        cout << enemyOrcImageHit2;
        cout << enemyOrcImageHit3;
        cout << enemyOrcImageHit4;
        cout << enemyOrcImageHit5;
        cout << enemyOrcImageHit6;
        cout << enemyOrcImageHit7;
        cout << enemyOrcImageHit8;
        cout << enemyOrcImageHit9;
        cout << enemyOrcImageHit10;
        cout << enemyOrcImageHit11;
        cout << enemyOrcImageHit12;
        cout << enemyOrcImageHit13;
        cout << enemyOrcImageHit14;
        cout << enemyOrcImageHit15;
        cout << enemyOrcImageHit16;
        cout << enemyOrcImageHit17;
        cout << enemyOrcImageHit18;
        cout << enemyOrcImageHit19;
        cout << enemyOrcImageHit20;
        cout << enemyOrcImageHit21;
    }
}

//animates images of enemy
void displayEnemyHit(string enemyType)
{
    clearScreen();
    cout << menuBar << "\n\n";
    displayEnemyShift(enemyType);
    cout << menuBar << "\n\n";
    usleep(300000);
    clearScreen();
    cout << menuBar << "\n\n";
    displayEnemy(enemyType);
    cout << menuBar << "\n\n";
    usleep(300000);
    clearScreen();
    cout << menuBar << "\n\n";
    displayEnemyShift(enemyType);
    cout << menuBar << "\n\n";
    usleep(300000);
    clearScreen();
    cout << menuBar << "\n\n";
    displayEnemy(enemyType);
    cout << menuBar << "\n\n";
    usleep(300000);
    clearScreen();
    cout << menuBar << "\n\n";
    displayEnemyShift(enemyType);
    cout << menuBar << "\n\n";
    usleep(300000);
    clearScreen();
    cout << menuBar << "\n\n";
    displayEnemy(enemyType);
}
