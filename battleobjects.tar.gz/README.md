textAdventure
=============
File Explanations:
-----------------
* main.cpp - main file, run this to create binary
* create.h - header with code for setting up the character
* inv.h - header with code for the inventory system
* level1.h - header with code containing the first level
* menus.h - header with code for the menu system.
* money.h - header containing the monetary system
* enemies.h - header with code for enemy system

