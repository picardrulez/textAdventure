using namespace std;

void level1();
void menuChoices();
